/*=================================================
 FILE: ChangeDenomination.java
 AUTHOR: Axel Troy A. Carabio
 DESCRIPTION: Change Denomination modularized using methods
 COPYRIGHT:09/25/2025
 DATE: BY: DESCRIPTION
 ==================================================*/


package LE1_1;

import java.util.Scanner;

public class ChangeDenomination {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("LE11 Change Denomination");

        // Create object
        Denomination denom = new Denomination();

        // Get input
        denom.getInput(scan);

        // Validate and compute
        if (denom.isValidAmount()) {
            denom.computeChange();
            denom.displayChange();
        } else {
            System.out.println("Enter integers within the specific parameters only!");
        }

        scan.close();
    }
}
