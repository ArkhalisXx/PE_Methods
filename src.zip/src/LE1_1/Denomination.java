package LE1_1;
import java.util.Scanner;

public class Denomination {
    private int amount;
    private int quarters;
    private int dimes;
    private int nickels;
    private int pennies;

    // Method to get input
    public void getInput(Scanner scan) {
        System.out.print("Enter amount (from 1 - 99 cents): ");
        if (scan.hasNextInt()) {
            amount = scan.nextInt();
        } else {
            System.out.println("Enter integers only!");
            amount = -1; // invalid
        }
    }

    // Method to validate input
    public boolean isValidAmount() {
        return (amount > 0 && amount < 100);
    }

    // Method to compute denominations
    public void computeChange() {
        quarters = amount / 25;
        amount %= 25;

        dimes = amount / 10;
        amount %= 10;

        nickels = amount / 5;
        amount %= 5;

        pennies = amount;
    }

    // Method to display result
    public void displayChange() {
        System.out.println("Your change is:");
        System.out.println(quarters + " quarter(s)");
        System.out.println(dimes + " dime(s)");
        System.out.println(nickels + " nickel(s)");
        System.out.println(pennies + " penny(ies)");
    }
}