/*=================================================
 FILE: dth.java
 AUTHOR: Axel Troy A. Carabio
 COPYRIGHT:09/27/2025
 DESCRIPTION: A program that computes decimal number 
 into hexadecimal number (modularized using methods)
 ==================================================*/


package LE2_3;

import java.util.Scanner;

public class dth {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("LE 2.3 Dec to Hex");

        // Input
        InputHelper inputHelper = new InputHelper(scan);
        int decimal = inputHelper.getInput("Enter a decimal number: ");
        if (decimal == -1) {
            return; // invalid input
        }

        // Process
        DecimalToHex converter = new DecimalToHex();
        converter.decimal = decimal;
        converter.convertToHex();

        // Output
        ResultPrinter printer = new ResultPrinter();
        printer.decimal = decimal;
        printer.hex = converter.hex;
        printer.printHex();

        scan.close();
    }
}