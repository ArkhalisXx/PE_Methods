package LE2_3;

import java.util.Scanner;

public class InputHelper {
    private Scanner scan;  

    public InputHelper(Scanner scan) {
        this.scan = scan;
    }

    // Method to safely get an integer input
    public int getInput(String message) {
        System.out.print(message);
        if (scan.hasNextInt()) {
            return scan.nextInt();
        } else {
            System.out.println("Enter integers only!");
            scan.next(); // clear invalid input
            return -1;
        }
    }
}