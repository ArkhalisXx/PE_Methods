package LE2_3;

public class DecimalToHex {
    public int decimal;    
    public String hex;     

    // Method to convert decimal to hexadecimal
    public void convertToHex() {
        if (decimal == 0) {
            hex = "0";
            return;
        }

        String result = "";
        int number = decimal;

        while (number > 0) {
            int remainder = number % 16;
            char hexChar;

            if (remainder < 10) {
                hexChar = (char) ('0' + remainder); // 0-9
            } else {
                hexChar = (char) ('A' + (remainder - 10)); // A-F
            }

            result = hexChar + result;
            number = number / 16;
        }

        hex = result;
    }
}