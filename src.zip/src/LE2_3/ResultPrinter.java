package LE2_3;

public class ResultPrinter {
    public int decimal;   
    public String hex;    

    // Method to print results
    public void printHex() {
        System.out.println("Decimal number     : " + decimal);
        System.out.println("Hexadecimal number : " + hex);
    }
}