package LE1_4;

public class DistanceCalculator {
    private Point p1;
    private Point p2;

    public DistanceCalculator(Point p1, Point p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    public double calculate() {
        double dx = p2.getX() - p1.getX();
        double dy = p2.getY() - p1.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }
}