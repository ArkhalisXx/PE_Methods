/*=================================================
 FILE: Dbtp.java
 AUTHOR: Axel Troy A. Carabio
 DESCRIPTION: Distance between Two Points modularized 
 using methods
 COPYRIGHT:09/25/2025
 DATE: BY: DESCRIPTION
 ==================================================*/


package LE1_4;

import java.util.Scanner;

public class Dbtp {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("LE14 Distance between Two Points");

        System.out.print("Enter x1: ");
        double x1 = scan.nextDouble();
        System.out.print("Enter y1: ");
        double y1 = scan.nextDouble();

        System.out.print("Enter x2: ");
        double x2 = scan.nextDouble();
        System.out.print("Enter y2: ");
        double y2 = scan.nextDouble();

        // Create objects
        Point p1 = new Point(x1, y1);
        Point p2 = new Point(x2, y2);

        DistanceCalculator calc = new DistanceCalculator(p1, p2);

        // Output
        System.out.println("The distance between the two points is " + calc.calculate());

        scan.close();
    }
}