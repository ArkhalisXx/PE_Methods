package LE2_1;

public class ResultPrinter {
    public String result; 

    public void printResult() {
        System.out.println("Day of the week is " + result);
    }
}