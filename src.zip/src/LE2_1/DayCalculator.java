package LE2_1;

public class DayCalculator {
    public int year;   
    public int month;
    public int day;

    public String calculateDayOfWeek() {
        int y = year;
        int m = month;

        // Adjust for Jan and Feb
        if (m == 1) {
            m = 13;
            y -= 1;
        } else if (m == 2) {
            m = 14;
            y -= 1;
        }

        int q = day;
        int k = y % 100; // Year of the century
        int j = y / 100; // Zero-based century

        int h = (q + (26 * (m + 1)) / 10 + k + (k / 4) + (j / 4) + (5 * j)) % 7;

        String[] days = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        return days[h];
    }
}
