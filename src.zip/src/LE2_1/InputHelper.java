package LE2_1;
import java.util.Scanner;

public class InputHelper {
    private Scanner scan;  // attribute

    public InputHelper(Scanner scan) {
        this.scan = scan;
    }

    public int getInput(String message) {
        System.out.print(message);
        if (scan.hasNextInt()) {
            return scan.nextInt();
        } else {
            System.out.println("Enter integers only!");
            scan.next(); // clear invalid input
            return -1;
        }
    }

    public boolean isValid(int value, int min, int max) {
        return (value >= min && value <= max);
    }
}