/*=================================================
 FILE: dotw.java
 AUTHOR: Axel Troy A. Carabio
 COPYRIGHT:09/24/2025
 DESCRIPTION: Tells the user the day of the week of 
 the inputed date (modularized using methods)
 ==================================================*/


package LE2_1;

import java.util.Scanner;

public class dotw {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("LE 2.1 Day of the Week");

        // Create objects
        InputHelper inputHelper = new InputHelper(scan);
        DayCalculator calculator = new DayCalculator();
        ResultPrinter printer = new ResultPrinter();

        // Input
        int year = inputHelper.getInput("Enter year (e.g., 2012): ");
        if (year == -1) return;

        int month = inputHelper.getInput("Enter month (1-12): ");
        if (month == -1 || !inputHelper.isValid(month, 1, 12)) {
            System.out.println("Enter only in the accepted parameters");
            return;
        }

        int day = inputHelper.getInput("Enter the day of the month (1-31): ");
        if (day == -1 || !inputHelper.isValid(day, 1, 31)) {
            System.out.println("Enter only in the accepted parameters");
            return;
        }

        // Calculation
        calculator.year = year;
        calculator.month = month;
        calculator.day = day;

        String result = calculator.calculateDayOfWeek();

        // Output
        printer.result = result;
        printer.printResult();

        scan.close();
    }
}